/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.projeto.login;

/**
 *
 * @author 04664896093
 */
public class Login {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
